import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SlidingListPage } from '../sliding-list/sliding-list';
import { ThumbnailListPage } from '../thumbnail-list/thumbnail-list';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  constructor(public navCtrl: NavController) {

  }

  gotoSlidingList()
  {
    this.navCtrl.push(SlidingListPage);
  }

  gotoThumbnailList()
  {
    this.navCtrl.push(ThumbnailListPage); 
  }
}
