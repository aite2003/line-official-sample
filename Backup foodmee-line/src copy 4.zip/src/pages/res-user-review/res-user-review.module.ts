import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResUserReviewPage } from './res-user-review';

@NgModule({
  declarations: [
    ResUserReviewPage,
  ],
  imports: [
    IonicPageModule.forChild(ResUserReviewPage),
  ],
})
export class ResUserReviewPageModule {}
