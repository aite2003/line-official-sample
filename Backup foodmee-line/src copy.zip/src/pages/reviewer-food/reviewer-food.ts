import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, NavPush } from 'ionic-angular';

/**
 * Generated class for the ReviewerFoodPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reviewer-food',
  templateUrl: 'reviewer-food.html',
})
export class ReviewerFoodPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReviewerFoodPage');
  }

  gotoAdd()
  {
    this.navCtrl.push("ReviewerFoodAddPage")
  }

}
