import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResPickOriginPage } from './res-pick-origin';

@NgModule({
  declarations: [
    ResPickOriginPage,
  ],
  imports: [
    IonicPageModule.forChild(ResPickOriginPage),
  ],
})
export class ResPickOriginPageModule {}
