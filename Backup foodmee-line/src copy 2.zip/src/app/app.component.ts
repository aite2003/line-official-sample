import { Component,ViewChild } from '@angular/core';
import { Platform ,Nav} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { TabsPage } from '../pages/tabs/tabs';
import { StartPage } from '../pages/start/start';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
    @ViewChild(Nav) nv: Nav;
  rootPage:any="FoodMapsPage";
  pages:any=[];
  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen
    ) {
    platform.ready().then(() => {

      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();

      this.pages = [
        { title: 'ร้านอาหารใกล้คุณ', component: "FoodMapsPage",icon:"ios-pin-outline" },
        { title: 'ร้านทั้งหมด', component: "FoodAllPage",icon:"md-search" },
        { title: 'ทำอะไรกินดี', component: "FoodAllPage",icon:"ios-restaurant" },
        { title: 'รีวิวร้านอาหาร', component: "ReviewerFoodPage" ,icon:"md-chatbubbles"},
        { title: 'วงล้อสุ่มกินอะไรดี', component: "RandomFoodPage",icon:"ios-create-outline" }
      ];

      

      //Line login get params
      let url=window.location.href;

        let urlParamS =  url.split("?");

        if(urlParamS[1]) //ถ้า redirect มาจาก LINE login
        {
          let lineParam=atob(urlParamS[1]);
console.log(lineParam);
          localStorage.setItem('line-param',lineParam);
          window.location.replace(location.origin+"/#/food-maps");


         // console.log(lineParam.id);
          //console.log(lineParam.name);
          //console.log(lineParam.picture);
        }






    });
    
    
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nv.setRoot(page.component);
  }
  


  screenWidth()
  {
    
    //console.log(window.innerWidth);
    if(window.innerWidth>500)
    {
      return {"width":"50%",left:"25%"};

    }
    else
    {
      return {"width":"100%"};
    }

  }
}
