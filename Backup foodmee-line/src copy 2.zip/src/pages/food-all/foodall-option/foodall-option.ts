import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the FoodmapsOptionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-foodall-option',
  templateUrl: 'foodall-option.html',
})
export class FoodallOptionPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    let tel=navParams.get('tel');
    let latlong=navParams.get('latlong');
    console.log(tel);
    console.log(latlong);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FoodmapsOptionPage');
  }

}
